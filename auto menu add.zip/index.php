<?php
// Database configuration
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'website';

// Create database connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch menu items from the database
$sql = "SELECT name, link FROM menu";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        nav {
            background-color: #333;
            color: white;
            padding: 10px;
        }
        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        nav ul li {
            margin-right: 20px;
        }
        nav ul li a {
            color: white;
            text-decoration: none;
        }
        .container {
            padding: 20px;
        }
    </style>
</head>
<body>
    <nav>
        <ul>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<li><a href='" . $row['link'] . "'>" . $row['name'] . "</a></li>";
                }
            } else {
                echo "<li>No menu items found</li>";
            }
            ?>
        </ul>
    </nav>
    <div class="container">
        <h1>Welcome to the Homepage</h1>
        <p>This is a sample homepage with a dynamic menu.</p>
    </div>
</body>
</html>

<?php
// Close database connection
$conn->close();
?>
